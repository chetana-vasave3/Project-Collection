use classicmodels;
/*QUESTION: List the largest single payment done by every customer in the year 2004, ordered by the transaction value (highest to lowest).
*/
use classicmodels;
select * from customers;
select * from payments;
#select month(paymentDate) as Year from payments;
select day(paymentDate) as year from payments  where year(paymentDate)=2004;




SELECT customerNumber, 
	MAX(amount) AS largestPayment 
    FROM payments 
    WHERE YEAR(paymentDate)=2004 
    GROUP BY customerNumber 
    ORDER BY largestPayment DESC;
    
    /*QUESTION: Show the total payments received month by month for every year.*/
SELECT YEAR(paymentDate) as year, 
	MONTH(paymentDate) as month, 
	ROUND(SUM(amount), 2) as totalPayments
    FROM payments 
    GROUP BY year, month
    ORDER BY year, month;
    
/*QUESTION: For the above query, format the amount properly with a dollar symbol and comma separation (e.g $26,267.62), and also show the month as a string.*/

SELECT YEAR(paymentDate) as year, 
	DATE_FORMAT(paymentDate, "%b") AS monthName, 
	CONCAT("$", FORMAT(SUM(amount), 2)) AS totalPayments
    FROM payments 
    GROUP BY year, MONTH(paymentDate), monthName
    ORDER BY year, MONTH(paymentDate);
    
create table demo(name char(25), age int);
insert into demo(name,age) values("chetana",26),("gauri",22);
select * from demo;
update demo set name="trupti",age=29
where name="trupti";
delete from demo where name="trupti";
use classicmodels;
select * from orders;
desc orders;
select year(orderDate) from orders;
select month(orderDate) from orders;
select date(orderDate) from orders;