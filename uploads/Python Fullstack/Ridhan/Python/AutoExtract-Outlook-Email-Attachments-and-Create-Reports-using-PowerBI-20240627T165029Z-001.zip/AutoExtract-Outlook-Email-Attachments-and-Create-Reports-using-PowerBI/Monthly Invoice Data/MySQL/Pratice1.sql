use classicmodels;
select * from customers;
/*List the customers in the United States with a credit limit higher than \$1000.*/
select * from customers where country = 'USA' and creditlimit>1000;


/*List the employee codes for sales representatives of customers in Spain, France and Italy. Make another query to list the names and email addresses of those employees.*/
select * from employees;
select distinct customerNumber from customers where country='Spain'or country='Italy' or country='France';
select firstname,email from employees where employeenumber in (1370,1337,1702,1401);
/*Change the job title "Sales Rep" to "Sales Representative"*/
set sql_safe_updates=0;
update employees set jobtitle='sales representative' where jobTitle='Sales Rep';
set sql_safe_updates=1;
/*Delete the entries for Sales Representatives working in London.*/
set foreign_key_checks=0;
DELETE FROM employees WHERE jobTitle = 'Sales Representative' AND officeCode=7;
set foreign_key_checks=1;
/*Show a list of employees who are not sales representatives*/
select * from employees where jobTitle !='Sales Representattives';


/*Show a list of customers with "Toys" in their name*/
select * from customers where customerName like '%Toys%';


select * from products;
/*List the 5 most expensive products from the "Planes" product line*/
select productName,productLine from products where productLine="Planes" order by buyprice desc limit 5;
/*Identify the products that are about to run out of stock (quantity in stock < 100)*/
select productName,quantityInStock from products where quantityInStock<100;
/*List 10 products in the "Motorcycles" category with the lowest buy price and more than 1000 units in stock*/
select productName,buyPrice,quantityInStock,productLine from products where productLine='Motorcycles' and quantityInStock>1000
order by buyPrice limit 10;


/*Retrieve details of all the customers in the United States who have made payments between April 1st 2003 and March 31st 2004.*/
SELECT * FROM customers WHERE customerNumber in 
(SELECT DISTINCT customerNumber FROM payments WHERE paymentDate>"2003-04-01" and paymentDate<"2004-03-31" and country='USA');


/*Determine the total number of units sold for each product*/
select * from orderdetails;
SELECT productCode, SUM(quantityOrdered) AS sold_units FROM orderdetails GROUP BY productCode;


/*Modify the above query to also show the minimum, maximum and average payment value for each customer.*/
select * from payments;
select customerNumber,MIN(amount) AS min_amount,MAX(amount) AS max_amount, AVG(amount) AS average_amount
FROM payments 
WHERE paymentdate < '2004-10-28' GROUP BY customernumber;


/*Show the full office address and phone number for each employee.*/
select * from offices;
SELECT employees.employeeNumber, addressLine1,addressLine2, phone, offices.officeCode 
FROM offices 
JOIN employees ON offices.officeCode=employees.officeCode;


/*Show the full order information and product details for order no. 10100.*/
SELECT ordernumber, products.productcode, products.productname,
products.productdescription,quantityordered, priceeach, 
orderlineNumber FROM orderdetails 
JOIN products ON orderdetails.productcode= products.productcode 
WHERE ordernumber='10100';
