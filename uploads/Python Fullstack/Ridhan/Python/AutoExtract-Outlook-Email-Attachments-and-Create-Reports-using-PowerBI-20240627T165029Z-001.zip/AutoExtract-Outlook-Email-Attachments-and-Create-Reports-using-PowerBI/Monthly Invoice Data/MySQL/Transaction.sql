/* transaction is a set of command that behaves like 1 autommic unit.
this are very imp when it comes to specially financial appliocations.
e.g. simple bank acc
let say u want to transfer amount from 1 acc to another acc. 
so i have account table where i have columns like acc_no,acc_name,balance. */
create table Account_data(Acc_No int, Acc_Name varchar(25),Balance float);
insert into Account_data values(1,"chetana",10000);
insert into Account_data values(2,"Sahil",20000);
select * from Account_data;

/* now i want to transfer balance 5k from acc1 to acc2..so in acc1 the balance should be 5000 and in acc2 balance is 25000
this is our debit operation*/

/*now i have another table transaction where we keep track of every trasactions,
which has columns acc_no,trasanction_type, Amount*/

/*
update the acc table(debit operation)
set balance=old balance-5k
where acc_no=1

update the acc table(credit operation)
set balance=old balance+5k
where acc_no=2

now again transaction table will get update like
acc_no    trasanction_type     Amount
1         Debited               5000
2         credited              5000

*/

