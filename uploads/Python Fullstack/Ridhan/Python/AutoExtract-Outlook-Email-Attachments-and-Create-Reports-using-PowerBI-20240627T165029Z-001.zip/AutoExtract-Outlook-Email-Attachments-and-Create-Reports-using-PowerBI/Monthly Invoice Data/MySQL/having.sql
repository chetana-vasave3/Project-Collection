use  students;
select * from placement;


/*having cluase with group by*/

select sum(Salary),count(region),region
from placement
group by region
having count(*);

