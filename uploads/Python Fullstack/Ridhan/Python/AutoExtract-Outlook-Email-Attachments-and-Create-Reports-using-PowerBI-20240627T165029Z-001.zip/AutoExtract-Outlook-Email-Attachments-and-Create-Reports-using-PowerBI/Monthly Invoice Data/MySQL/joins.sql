/*QUESTION: Show the 10 most recent payments with customer details (name & phone no.)*/

SELECT checkNumber, paymentDate, amount, customers.customerNumber, customerName, phone 
	FROM payments JOIN customers 
    ON payments.customerNumber=customers.customerNumber 
    ORDER BY paymentDate DESC LIMIT 10;