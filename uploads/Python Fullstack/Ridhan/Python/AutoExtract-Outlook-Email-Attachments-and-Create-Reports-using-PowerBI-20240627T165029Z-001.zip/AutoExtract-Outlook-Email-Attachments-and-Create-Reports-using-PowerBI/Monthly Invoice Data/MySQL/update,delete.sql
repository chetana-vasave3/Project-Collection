use students;
show tables;
select * from departments;
update departments set Dept_Name="IT" where Student_name="chetana";
desc departments;

update departments set Joinig_date="2023-11-25" where Student_name="Sayli";

update departments set city="nagpur" where city="0";
update departments set Joinig_date="2023-11-24" where city="Ratnagiri";

delete from departments where Joinig_date is null;
