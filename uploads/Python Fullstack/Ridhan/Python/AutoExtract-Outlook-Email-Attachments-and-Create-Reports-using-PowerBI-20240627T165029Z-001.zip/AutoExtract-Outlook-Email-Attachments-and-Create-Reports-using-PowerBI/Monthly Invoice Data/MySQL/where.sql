show databases;
use ipcs;
show tables;
select * from ipcs_data;
update ipcs_data  set Name="chetana" where ID=2;


use classicmodels;
show tables;
select * from payments;
select paymentDate,amount from payments where amount>10000;

use project1;
show tables;
select * from orders;
select OrderID,EmployeeID from orders where EmployeeID!=4;
select OrderID,EmployeeID from orders where EmployeeID<>2;

select * from products;
select productName,buyPrice from products where buyPrice between 22 and 28;
select ProductName,buyPrice from products where buyPrice in(30,22,25,56);
select * from products where SupplierID=1 or Price=15;



/*like operator*/
select ProductName from products where ProductName like "c%";
select ProductName from products where ProductName like "b%";
select ProductName from products where ProductName like "%a";
select ProductName from products where ProductName like "%ar%";
select ProductName from products where ProductName like "_a%";
select ProductName from products where ProductName like "__a%";
select ProductName from products where ProductName like "a%t";
select ProductName from products where ProductName like "__g%";
select ProductName from products where ProductName like "a__%_%";