use employee;
show tables;
select * from employee_data;
update employee_data set city="pune" where city is null;
update employee_data set emp_id=10 where emp_id=4;
select emp_name, emp_salary from employee_data where emp_salary<30000;